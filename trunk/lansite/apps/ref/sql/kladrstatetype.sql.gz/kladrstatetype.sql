INSERT INTO `ref_kladrstatetype` (`id`, `comments`) VALUES (1,'Центр района');
INSERT INTO `ref_kladrstatetype` (`id`, `comments`) VALUES (2,'Центр региона');
INSERT INTO `ref_kladrstatetype` (`id`, `comments`) VALUES (3,'Центр района и региона');
INSERT INTO `ref_kladrstatetype` (`id`, `comments`) VALUES (4,'Центральный район');
